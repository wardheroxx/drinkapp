package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }




    public boolean validationEmail(String email) {

        String[] splitString = email.split("@");
        if (splitString.length != 2) {
            Toast.makeText(MainActivity.this, "Incorrect usernameor password", Toast.LENGTH_SHORT).show();
            return false;
        }

        String username = splitString[0];
        String domain = splitString[1];

        if (!(username.length() >= 3 && username.length() <= 70)) {
            Toast.makeText(MainActivity.this, "Incorrect usernameor password", Toast.LENGTH_SHORT).show();
            return false;
        }
        for (int i = 0; i < username.length(); i++) {
            if (username.charAt(i) == ' ') {
                Toast.makeText(MainActivity.this, "Incorrect usernameor password", Toast.LENGTH_SHORT).show();
                return false;
            }
        }

        if (!(username.charAt(0) >= 'a' && username.charAt(0) < 'z' || username.charAt(0) >= 'A' && username.charAt(0) < 'Z' || username.charAt(0) == '_'))
            ;
        {
            Toast.makeText(MainActivity.this, "Incorrect usernameor password", Toast.LENGTH_SHORT).show();
            return false;
        }
        for (int i = 1; i <= username.length(); i++) {
            if (!(username.charAt(i) >= 'a' && username.charAt(i) < 'z' || username.charAt(i) >= '0' && username.charAt(i) < '9' || username.charAt(0) == '.' || username.charAt(0) == '_'))
                Toast.makeText(MainActivity.this, "Incorrect usernameor password", Toast.LENGTH_SHORT).show();
        }
        if (!(domain.charAt(0) >= 'a' && domain.charAt(0) < 'z' || domain.charAt(0) >= '0' && domain.charAt(0) < '9' || domain.charAt(0) == '_'))
            Toast.makeText(MainActivity.this, "Incorrect usernameor password", Toast.LENGTH_SHORT).show();
        return false;


        String[] splitDomain = email.split(".");
        if (!(splitString.length >= 1 && splitString.length <= 3)) {
            Toast.makeText(MainActivity.this, "Incorrect usernameor password", Toast.LENGTH_SHORT).show();
            return false;
        }

        for (int i = 1; i <= domain.length(); i++)
        { if (!(domain.charAt(i) >= 'a' && domain.charAt(i) < 'z' || domain.charAt(i) >= '0' && domain.charAt(i) < '9' || domain.charAt(0) == '_'))
            Toast.makeText(MainActivity.this, "Incorrect usernameor password", Toast.LENGTH_SHORT).show();
        }
        return false;
    }


    }

